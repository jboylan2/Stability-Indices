/**************************************************************
 Purpose/Description: Algorithm determines if given input is in the array
 Author’s Panther ID: 6220985
 Certification:
 I hereby certify that this work is my own and none of it is the work of
 any other person.
**************************************************************/
import java.util.Scanner;
public class Problem2A {
    
    static int binarySearch(int A[],int l,int r, int x){
        
        if(r >= l){
            int mid = l + (r - l) / 2;
        
            if(A[mid] == x)
                return mid;
            
            if(A[mid] > x)
                return binarySearch(A, 1, mid- 1, x);
        
            return binarySearch(A, mid+1,r, x);
        }
    return -1;
    }
    //method finds max value in the array
    static int findMax(int A[]){
      int i;
      int max = 0;
      for(i=0; i < A.length; i++)
        if(A[i] > A[max])
            max = i;
      return max;
    }
   
                
                
                
    public static void main(String[] args) {
        
        int A[] = {2, 3, 5, 7, 9, 11, 8, 4, 1, -2, -4};
        int n = A.length;
        Scanner in = new Scanner(System.in); 
        System.out.println("Enter a number to search for: ");
        int x = in.nextInt();
        
        //find max of array
        int mid = findMax(A);
        
        //creates a second array from max value to end 
        int[] secondHalf = new int[A.length - (mid+1)];
        System.arraycopy(A, (mid+1), secondHalf, 0, A.length - (mid+1));
        
        //call binary search on both arrays to locate index of inputed value
        int result1 = binarySearch(A, 0, mid, x);
        int result2 = binarySearch(secondHalf, 0, (secondHalf.length-1), x );
        result2 += secondHalf.length + 1;
        
        //print index if it exists
        if(result1 == -1 && result2 == -1)
            System.out.print("Element does not exist \n");
        else if (result1 == -1)
            System.out.println("Element exists at " + result2);
        else 
            System.out.println("Element exists at " + result1);
            
        }
        
    }

    

