/**************************************************************
 Purpose/Description: Algorithm sees if input is in 2D Array
 Author’s Panther ID: 6220985
 Certification:
 I hereby certify that this work is my own and none of it is the work of
 any other person.
**************************************************************/

import java.util.Scanner;
public class Project2B {

   
    public static void searchArray(int[][] A, int n, int x){
        int i=0;
        int j= n-1;
        //while loop iterates through the array and finds exact array index of input
        while(i<n && j>=0) {
            if(A[i][j]==x){
                System.out.print("n is present at A[" +i+"]"+"["+j+"]\n3");
                return;
            }
            if(A[i][j]<x)
                j--;
            else
                i++;
        }
        System.out.print("Element is not found \n" );
        return;
    }
        
  
    public static void main(String[] args) {
        
        int x;
        //2D Array declared
        int A[][]= {{32,27,22,18},{31,25,21,16},{29,24,17,12},{28,22,14,8}};
        
        System.out.print("Searched Integer: ");
        Scanner in= new Scanner(System.in);
        x= in.nextInt();
          searchArray(A,4,x);
    }
}
        
        
        
    
    

