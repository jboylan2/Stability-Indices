/**************************************************************
 Purpose/Description: Algorithm to find Stability Indicies
 Author’s Panther ID: 6220985
 Certification:
 I hereby certify that this work is my own and none of it is the work of
 any other person.
**************************************************************/

public class Problem1 {
    
    public static String findStabilityIndicies(int[] array) {
        int arraySum = 0;
        int leftSum = 0;
        String indicies = "";
       
        //for loop iterates each time to find the sum 
        for(int i = 0; i < array.length; i++) {
            arraySum += array[i];
        }
        /*Each iteration the current element is subtracted from total array sum
          Current array sum is compared to the left sum and if equal then the current
          index is a stabiliy index. Then the curren index's value is added to the leftSum*/
        for(int i =0; i < array.length; i++) {
            arraySum -= array[i];
            if(leftSum == arraySum)
            {
                indicies += i + " ";
            }
            leftSum += array[i];
        }
        
        return indicies;
    }

    //declares elements in array then outputs the indicies
    public static void main(String[] args) {
        int A[] = {0, -3, 5, -4, -2, 3, 1, 0};
            
        System.out.println(findStabilityIndicies(A));    
      
    }
    
    
}
